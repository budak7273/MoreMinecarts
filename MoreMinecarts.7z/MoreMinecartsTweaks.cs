using CoreLib.Submodules.ModEntity.Atributes;
using PugMod;
using Unity.Entities;
using UnityEngine;

[EntityModification]
public static class MoreMinecartsTweaks
{
    [EntityModification(ObjectID.RailwayForge)]
    private static void EditRailwayForge(Entity entity, GameObject authoring, EntityManager entityManager)
    {
        var canCraftBuffer = entityManager.GetBuffer<CanCraftObjectsBuffer>(entity);

        addBufferEntry(ref canCraftBuffer, API.Authoring.GetObjectID("MoreMinecarts:CartScarlet"));
        //addBufferEntry(ref canCraftBuffer, API.Authoring.GetObjectID("MoreMinecarts:CartSolarite"));
        addBufferEntry(ref canCraftBuffer, API.Authoring.GetObjectID("MoreMinecarts:LegendaryCartParchment"));
    }

    private static void addBufferEntry(ref DynamicBuffer<CanCraftObjectsBuffer> canCraftBuffer, ObjectID itemId)
    {
        canCraftBuffer.Add(new CanCraftObjectsBuffer
        {
            objectID = itemId,
            amount = 1,
            entityAmountToConsume = 0
        });
    }
}
